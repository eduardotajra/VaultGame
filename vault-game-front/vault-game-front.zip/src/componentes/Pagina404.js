function Page404(){
    return(
        <div>Página não encontrada</div>
    )
}
export default Page404